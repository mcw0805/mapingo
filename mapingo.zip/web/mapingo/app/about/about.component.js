angular.module('about').component('about', {
    templateUrl: 'about/about.template.html',

    controller: [function aboutController() {
        var self = this;
    }]
});