# Mapingo
Mapingo is like Tapingo, but it's approximately seventeen and half times better. By optimizing orders based on location, Mapingo makes waiting for food a thing of the past.

Created by Chaewon Min and Deb Banerji at HackEmory 2017